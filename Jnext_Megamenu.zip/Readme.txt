Plugin Name: Jnext Megamenu
Company: Jnext Development
Developer: MuradAli
Compatible: Upto Magento 2.0.9